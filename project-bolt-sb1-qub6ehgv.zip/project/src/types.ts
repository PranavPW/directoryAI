// Add to existing types.ts
export interface TrendingTopic {
  id: string;
  rank: number;
  previousRank: number;
  title: string;
  totalMentions: number;
  engagement: {
    twitter: number;
    instagram: number;
    facebook: number;
    tiktok: number;
  };
  keyInfluencers: string[];
  hashtags: string[];
  context: string;
  sentiment: {
    positive: number;
    negative: number;
    neutral: number;
  };
  demographics: {
    ageGroups: Record<string, number>;
    gender: Record<string, number>;
  };
  peakActivity: string;
  geography: Record<string, number>;
}