import React, { useState } from 'react';
import { ExternalLink, Star, ArrowUp } from 'lucide-react';
import { AITool } from '../types';

interface ToolCardProps {
  tool: AITool;
}

export default function ToolCard({ tool }: ToolCardProps) {
  const [upvotes, setUpvotes] = useState(generateRealisticUpvotes());
  const [hasUpvoted, setHasUpvoted] = useState(false);

  function generateRealisticUpvotes() {
    // Generate a realistic base number between 50-500
    const base = Math.floor(Math.random() * 450) + 50;
    // Add some random variation
    return base + Math.floor(Math.random() * 20);
  }

  const handleUpvote = () => {
    if (!hasUpvoted) {
      setUpvotes(prev => prev + 1);
      setHasUpvoted(true);
    }
  };

  return (
    <div className="bg-gradient-to-br from-white to-blue-50 rounded-xl shadow-sm border border-blue-100 hover:shadow-lg transition-all duration-300">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{tool.name}</h3>
            <p className="text-sm text-blue-600 font-medium">{tool.category}</p>
          </div>
          
          <button 
            onClick={handleUpvote}
            className={`flex flex-col items-center p-2 rounded-lg transition-all duration-300 ${
              hasUpvoted 
                ? 'bg-blue-100 text-blue-600' 
                : 'hover:bg-blue-50 text-gray-500 hover:text-blue-600'
            }`}
          >
            <ArrowUp className={`h-5 w-5 ${hasUpvoted ? 'fill-current' : ''}`} />
            <span className="text-sm font-bold mt-1">{upvotes}</span>
          </button>
        </div>
        
        <div className="mt-3 flex items-center">
          <Star className="h-4 w-4 text-yellow-400 fill-current" />
          <span className="ml-1 text-sm font-medium text-gray-700">{tool.rating}</span>
          <span className="mx-2 text-gray-300">•</span>
          <span className="text-sm text-gray-600">{tool.reviews} reviews</span>
        </div>
        
        <p className="mt-3 text-gray-600">{tool.description}</p>
        
        <div className="mt-4 flex flex-wrap gap-2">
          {tool.tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 text-xs font-medium text-blue-700 bg-blue-100 rounded-full hover:bg-blue-200 transition-colors"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between items-center pt-4 border-t border-blue-100">
          <div className="text-sm">
            <span className="font-medium text-blue-900">{tool.pricing}</span>
          </div>
          <a
            href={tool.website}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Visit Site
            <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </div>
      </div>
    </div>
  );
}