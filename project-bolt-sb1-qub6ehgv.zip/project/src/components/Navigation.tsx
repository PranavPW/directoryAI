import React, { useState } from 'react';

const navItems = [
  { id: 'discover', label: 'Discover' },
  { id: 'trending', label: 'Trending' },
  { id: 'categories', label: 'Categories' },
  { id: 'news', label: 'News' },
  { id: 'submit', label: 'Submit Tool' }
];

export default function Navigation() {
  const [activeTab, setActiveTab] = useState('discover');

  return (
    <nav className="max-w-2xl mx-auto px-4">
      <ul className="flex justify-between space-x-2">
        {navItems.map(({ id, label }) => (
          <li key={id} className="flex-1">
            <button
              onClick={() => setActiveTab(id)}
              className={`
                w-full px-4 py-2 text-sm font-medium rounded-lg
                transition-all duration-300 ease-in-out
                relative overflow-hidden
                ${activeTab === id
                  ? 'text-blue-600 bg-blue-50 shadow-sm'
                  : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50/50'
                }
                before:absolute before:bottom-0 before:left-0 before:h-0.5
                before:w-full before:origin-left before:scale-x-0
                before:bg-blue-600 before:transition-transform before:duration-300
                hover:before:scale-x-100
                hover:shadow-[0_2px_8px_rgba(59,130,246,0.15)]
                focus:outline-none focus:ring-2 focus:ring-blue-200
              `}
            >
              {label}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}