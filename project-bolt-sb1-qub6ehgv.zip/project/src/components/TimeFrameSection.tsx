import React from 'react';
import { AITool, TimeFrame } from '../types';
import ToolCard from './ToolCard';

interface TimeFrameSectionProps {
  timeFrame: TimeFrame;
  tools: AITool[];
}

export default function TimeFrameSection({ timeFrame, tools }: TimeFrameSectionProps) {
  const titles = {
    daily: 'Daily Top 10',
    weekly: 'Weekly Roundup',
    monthly: 'Monthly Spotlight'
  };

  const descriptions = {
    daily: 'Most innovative AI tools launched in the last 24 hours',
    weekly: 'Most promising AI startups from the past 7 days',
    monthly: 'Breakthrough AI technologies and companies this month'
  };

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">{titles[timeFrame]}</h2>
          <p className="mt-2 text-lg text-gray-600">{descriptions[timeFrame]}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </div>
    </section>
  );
}