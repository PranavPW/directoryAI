import React, { useState } from 'react';
import { TrendingTopic } from '../types';
import { ArrowUp, ArrowDown, Minus, BarChart3, Globe, Users } from 'lucide-react';

interface TrendingTopicsProps {
  weeklyTopics: TrendingTopic[];
  monthlyTopics: TrendingTopic[];
}

export default function TrendingTopics({ weeklyTopics, monthlyTopics }: TrendingTopicsProps) {
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly'>('weekly');
  const topics = timeframe === 'weekly' ? weeklyTopics : monthlyTopics;

  const getRankChange = (current: number, previous: number) => {
    if (current === previous) return <Minus className="h-4 w-4 text-gray-400" />;
    return current < previous ? (
      <ArrowUp className="h-4 w-4 text-green-500" />
    ) : (
      <ArrowDown className="h-4 w-4 text-red-500" />
    );
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Trending Topics</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setTimeframe('weekly')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                timeframe === 'weekly'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Weekly
            </button>
            <button
              onClick={() => setTimeframe('monthly')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                timeframe === 'monthly'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Monthly
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {topics.map((topic) => (
            <div
              key={topic.id}
              className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-gray-900">
                        #{topic.rank}
                      </span>
                      {getRankChange(topic.rank, topic.previousRank)}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {topic.title}
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">{topic.context}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">
                        {topic.totalMentions.toLocaleString()} mentions
                      </div>
                      <div className="text-sm text-gray-500">
                        Peak: {topic.peakActivity}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        Sentiment
                      </div>
                      <div className="flex gap-2 text-sm">
                        <span className="text-green-600">
                          {topic.sentiment.positive}% pos
                        </span>
                        <span className="text-red-600">
                          {topic.sentiment.negative}% neg
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        Top Demographics
                      </div>
                      <div className="text-sm text-gray-600">
                        {Object.entries(topic.demographics.ageGroups)
                          .sort(([, a], [, b]) => b - a)
                          .slice(0, 1)
                          .map(([age, percentage]) => `${age}: ${percentage}%`)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        Top Regions
                      </div>
                      <div className="text-sm text-gray-600">
                        {Object.entries(topic.geography)
                          .sort(([, a], [, b]) => b - a)
                          .slice(0, 2)
                          .map(([region, percentage]) => `${region}: ${percentage}%`)
                          .join(', ')}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {topic.hashtags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 text-xs font-medium text-blue-600 bg-blue-50 rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}