import React from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import TimeFrameSection from './components/TimeFrameSection';
import NewsSection from './components/NewsSection';
import Newsletter from './components/Newsletter';
import TrendingTopics from './components/TrendingTopics';
import { AITool, NewsItem, TrendingTopic } from './types';

// Sample data
const sampleTools: AITool[] = [
  {
    id: '1',
    name: 'AI Writer Pro',
    description: 'Advanced AI writing assistant with context-aware suggestions',
    category: 'Generative AI',
    launchDate: new Date(),
    pricing: 'From $29/month',
    website: 'https://example.com',
    rating: 4.8,
    reviews: 128,
    metrics: {
      users: 5000,
      funding: '$2.5M'
    },
    tags: ['Writing', 'Content Creation', 'GPT-4']
  }
];

const sampleNews: NewsItem[] = [
  {
    id: '1',
    title: 'Revolutionary AI Model Achieves Human-Level Performance',
    source: 'TechCrunch',
    url: 'https://techcrunch.com',
    publishedAt: new Date(),
    category: 'Research'
  }
];

const sampleTrendingTopics: TrendingTopic[] = [
  {
    id: '1',
    rank: 1,
    previousRank: 3,
    title: 'GPT-5 Rumors',
    totalMentions: 1250000,
    engagement: {
      twitter: 450000,
      instagram: 300000,
      facebook: 200000,
      tiktok: 300000
    },
    keyInfluencers: ['OpenAI', 'Elon Musk', 'Sam Altman'],
    hashtags: ['GPT5', 'AINews', 'FutureOfAI'],
    context: 'Speculation about OpenAI\'s next large language model',
    sentiment: {
      positive: 65,
      negative: 15,
      neutral: 20
    },
    demographics: {
      ageGroups: { '25-34': 40, '18-24': 30, '35-44': 20 },
      gender: { male: 60, female: 35, other: 5 }
    },
    peakActivity: '2pm EST',
    geography: { 'United States': 45, 'Europe': 30, 'Asia': 15 }
  }
];

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="py-6">
        <Navigation />
      </div>
      <main>
        <TrendingTopics 
          weeklyTopics={sampleTrendingTopics} 
          monthlyTopics={sampleTrendingTopics} 
        />
        <TimeFrameSection timeFrame="daily" tools={sampleTools} />
        <TimeFrameSection timeFrame="weekly" tools={sampleTools} />
        <TimeFrameSection timeFrame="monthly" tools={sampleTools} />
        <NewsSection news={sampleNews} />
        <Newsletter />
      </main>
      
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>© 2024 AI Directory. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}